All the programming done for this assignment was on a windows machine. 
If you can, compile and run this java program on a windows computer. 
This program was never tested on a IOS machine.

I am going to assume that this program is going to be run on a windows computer and 
it has the java and javac program path attached to the environment variables

--------------------------------------------------------------------------------------

Before running the java program, put all the java file into one directory.

Open the command line in that directory.

To compile all java file, type 
	javac *.java

To run the java program, type 
	java CS4551_Tran
		ex. java CS4551_Tran
	
--------------------------------------------------------------------------------------

Compare A and C:
	A and C are almost identical, since IDCT contain double type values, If the IDCT double values were rounded up, A and C would be identical.
	

Note on submission: 
	I do not know if I am suppose to turn this assignment in. The CSNS DCT hands-on Activity description did not say anything about submitting code, but there is a option to upload our code. To be on the safe side, I am going to submit it. The submission style is going to be the same format as how the class uploads the homework.
