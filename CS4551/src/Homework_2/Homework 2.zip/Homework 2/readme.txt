All the programming done for this assignment was on a windows machine. 
If you can, compile and run this java program on a windows computer. 
This program was never tested on a IOS machine.

I am going to assume that this program is going to be run on a windows computer and 
it has the java and javac program path attached to the environment variables

--------------------------------------------------------------------------------------

Before running the java program, put all the java file into one directory.
In the same directory, put all the .txt files you want to compress.

Open the command line in that directory.

To compile all java file, type 
	javac *.java

To run the java program, type 
	java CS4551_Tran
		ex. java CS4551_Tran
		
All image and .txt file from the java program will be outputted 
in the same directory where the java program was ran in.
	
--------------------------------------------------------------------------------------

[Recommend]: the [input_filename] should be a file name inside the java program directory where you put all the java files in. Doing so will help the program output image and text files in the same directory.

Task 1 –Aliasing Finding: 

	For any radial circle that has no filter, the image is visionally less define from the original circle and filter counterparts. It is also very noticeable when the thickness of the line are smaller and/or the image resize is reduced.

	For radial circle that has filter 1, there is a faint pattern that shows at some parts of the lines with lesser thickness than the original circle and Filter 2 circle. It becomes more apparent when the image resize gets smaller.