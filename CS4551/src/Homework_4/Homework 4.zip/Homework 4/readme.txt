All the programming done for this assignment was on a windows machine. 
If you can, compile and run this java program on a windows computer. 
This program was never tested on a IOS machine.

I am going to assume that this program is going to be run on a windows computer and 
that it has the java and javac program path attached to the environment variables

--------------------------------------------------------------------------------------

Before running the java program, put all the java file into one directory.
Grab all the .ppm image files from the IDB and put it inside the Homework 4 directory.

Open the command line in that directory.

To compile all java file, type 
	javac *.java

To run the java program, type 
	java CS4551_Tran

An image and text files from this java program will be outputted 
in the Homework 4 directory.